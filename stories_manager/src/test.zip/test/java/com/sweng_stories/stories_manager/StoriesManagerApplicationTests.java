package com.sweng_stories.stories_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoriesManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
